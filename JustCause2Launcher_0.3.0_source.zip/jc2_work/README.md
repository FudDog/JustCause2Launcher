# Just Cause 2 Launcher — Android prototype 0.3.0

This is an installable Android launcher UI prototype. It is **not yet capable of running the Windows PC game** because a compatible Windows runtime and graphics translation stack are not bundled.

## Included in 0.3.0
- Native Android landscape launcher screen.
- Select a game folder using Android Storage Access Framework.
- Select and inspect a ZIP archive for `JustCause2.exe`.
- Persist selected source and basic preferences.
- Touch-control layout preview and saved button-size setting.
- Graphics profile selector (currently stores a UI preference only).
- Runtime status explanation.

## Not implemented yet
- Extracting a ZIP archive into a usable game directory.
- Actual touch input overlay connected to the game.
- Wine/Box64/DXVK or another compatible Windows runtime.
- Launching `JustCause2.exe`.

## Build an APK with GitHub Actions
1. Create a new empty GitHub repository.
2. Upload the contents of this project (the files inside this ZIP, not the ZIP itself) to the repository's `main` branch.
3. Open the repository's **Actions** tab and run **Build Android APK** (or wait for the push workflow).
4. Open the completed workflow run and download the `JustCause2Launcher-debug` artifact.
5. Extract the artifact ZIP; install `app-debug.apk` on Android. Android may ask you to allow installation from the browser/file manager.

The workflow uses JDK 17, Gradle 8.9, Android SDK platform 35 and produces a debug APK.
