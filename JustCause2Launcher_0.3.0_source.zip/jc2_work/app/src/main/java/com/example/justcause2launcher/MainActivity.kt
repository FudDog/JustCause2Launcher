package com.example.justcause2launcher

import android.app.*
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.documentfile.provider.DocumentFile
import java.io.File
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("jc2", MODE_PRIVATE) }
    private val io = Executors.newSingleThreadExecutor()
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var selected: TextView
    private lateinit var launch: Button
    private var gameFound = false
    private val bg = Color.rgb(12, 18, 27)
    private val panel = Color.rgb(25, 36, 50)
    private val accent = Color.rgb(255, 174, 40)

    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            prefs.edit().putString("folder", uri.toString()).putString("source", "folder").apply()
            selected.text = "Джерело: папка гри вибрана"
            scanFolder(uri)
        }
    }
    private val zipPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            prefs.edit().putString("zip", uri.toString()).putString("source", "zip").apply()
            selected.text = "Джерело: ZIP-архів вибраний"
            inspectZip(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg; window.navigationBarColor = bg
        buildHome()
        when (prefs.getString("source", "")) {
            "folder" -> prefs.getString("folder", null)?.let { scanFolder(Uri.parse(it)) }
            "zip" -> prefs.getString("zip", null)?.let { inspectZip(Uri.parse(it)) }
        }
    }

    private fun buildHome() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 18, 22, 22); setBackgroundColor(bg) }
        val scroll = ScrollView(this); scroll.addView(root); setContentView(scroll)
        root.addView(label("JUST CAUSE 2", 30f, accent, true).apply { gravity = Gravity.CENTER })
        root.addView(label("ANDROID LAUNCHER  •  ПРОТОТИП 0.3.0", 12f, Color.LTGRAY).apply { gravity = Gravity.CENTER })
        root.addView(space(14))
        val hero = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 16, 18, 16); setBackgroundColor(panel) }
        hero.addView(label("ПІДГОТОВКА ГРИ", 17f, Color.WHITE, true))
        selected = label("Джерело: не вибрано", 13f, Color.LTGRAY); hero.addView(selected)
        status = label("Статус: очікується вибір файлів гри", 14f, Color.WHITE); hero.addView(status)
        root.addView(hero)
        addButton(root, "ВИБРАТИ ПАПКУ З ГРОЮ") { folderPicker.launch(null) }
        addButton(root, "ВИБРАТИ ZIP-АРХІВ") { zipPicker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) }
        root.addView(space(8))
        root.addView(label("НАЛАШТУВАННЯ", 16f, accent, true))
        addButton(root, "Сенсорне керування") { showControls() }
        addButton(root, "Графіка та продуктивність") { showGraphics() }
        addButton(root, "Сумісність та рушій") { showRuntime() }
        launch = Button(this).apply {
            text = "ЗАПУСТИТИ JUST CAUSE 2"; isAllCaps = false; textSize = 16f
            setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(90, 65, 35)); isEnabled = false
            setOnClickListener { show("Запуск недоступний", "У цій демонстраційній збірці ще немає Windows runtime. Файли гри можна вибрати та перевірити, але виконати JustCause2.exe поки неможливо.") }
        }
        root.addView(launch, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 16 })
        root.addView(label("Поточна збірка демонструє інтерфейс та імпорт файлів. Це ще не емулятор Windows.", 11f, Color.GRAY))
    }

    private fun showControls() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 10, 20, 10) }
        box.addView(TextView(this).apply { text = "Попередній перегляд розкладки"; setTextColor(Color.WHITE); textSize = 16f })
        val preview = FrameLayout(this).apply { setBackgroundColor(Color.rgb(30, 43, 55)); minimumHeight = 220 }
        fun pad(text: String, gravity: Int, w: Int = 68, h: Int = 54) {
            val b = TextView(this).apply { this.text = text; gravity = Gravity.CENTER; textSize = 13f; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(75, 92, 108)) }
            val lp = FrameLayout.LayoutParams(w, h, gravity).apply { val m = 12; leftMargin=m; rightMargin=m; topMargin=m; bottomMargin=m }
            preview.addView(b, lp)
        }
        pad("РУХ", Gravity.BOTTOM or Gravity.START, 82, 82); pad("СТРИБОК", Gravity.BOTTOM or Gravity.END)
        pad("ГАЧОК", Gravity.CENTER or Gravity.END); pad("ПРИЦІЛ", Gravity.TOP or Gravity.END)
        box.addView(preview)
        val size = SeekBar(this).apply { max = 100; progress = prefs.getInt("button_size", 55) }
        box.addView(TextView(this).apply { text = "Розмір кнопок"; setTextColor(Color.WHITE) }); box.addView(size)
        size.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { if(user) prefs.edit().putInt("button_size", p).apply() }
            override fun onStartTrackingTouch(s: SeekBar?) {}; override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        AlertDialog.Builder(this).setTitle("Сенсорне керування").setView(box).setPositiveButton("Зберегти", null).show()
    }
    private fun showGraphics() {
        val options = arrayOf("Економний", "Збалансований", "Висока якість", "Максимальна якість")
        val current = prefs.getInt("graphics", 1).coerceIn(0, 3)
        AlertDialog.Builder(this).setTitle("Профіль графіки").setSingleChoiceItems(options, current) { d, which ->
            prefs.edit().putInt("graphics", which).apply(); d.dismiss()
            show("Профіль збережено", "Обрано: ${options[which]}. Поки що це збережений профіль інтерфейсу; на графіку гри він вплине після інтеграції рушія.")
        }.setNegativeButton("Закрити", null).show()
    }
    private fun showRuntime() = show("Стан рушія сумісності", "Windows runtime (наприклад Wine/Box64 та графічний транслятор) ще не вбудований. Це окремий великий етап розробки. Наявність лише лаунчера не дозволяє запускати PC-гру.")

    private fun scanFolder(uri: Uri) {
        status.text = "Статус: перевіряю папку…"
        io.execute {
            try {
                val rootDoc = DocumentFile.fromTreeUri(this, uri) ?: error("Не вдалося відкрити папку")
                var found = false; var count = 0
                fun walk(dir: DocumentFile, depth: Int) {
                    if (depth > 10 || count > 30000) return
                    dir.listFiles().forEach { f -> count++; if (f.isDirectory) walk(f, depth + 1) else if (f.name.equals("JustCause2.exe", true)) found = true }
                }
                walk(rootDoc, 0); gameFound = found
                runOnUiThread { status.text = if(found) "Знайдено JustCause2.exe • перевірено $count елементів" else "EXE не знайдено • перевірено $count елементів"; launch.isEnabled = false }
            } catch(e: Exception) { runOnUiThread { status.text = "Помилка: ${e.message}" } }
        }
    }
    private fun inspectZip(uri: Uri) {
        status.text = "Статус: перевіряю ZIP…"
        io.execute {
            try {
                val temp = File(cacheDir, "selected_game.zip")
                contentResolver.openInputStream(uri)?.use { input -> temp.outputStream().use { output -> input.copyTo(output) } } ?: error("Не вдалося прочитати архів")
                var found = false; var count = 0
                ZipFile(temp).use { z -> val entries = z.entries(); while(entries.hasMoreElements()) { val e=entries.nextElement(); count++; if(e.name.replace('\\','/').substringAfterLast('/').equals("JustCause2.exe", true)) found=true } }
                gameFound = found
                runOnUiThread { status.text = if(found) "У ZIP знайдено JustCause2.exe • $count елементів" else "EXE не знайдено • $count елементів"; launch.isEnabled = false }
            } catch(e: Exception) { runOnUiThread { status.text = "Помилка ZIP: ${e.message}" } }
        }
    }
    private fun addButton(parent: LinearLayout, title: String, action: () -> Unit) {
        val b = Button(this).apply { text = title; isAllCaps = false; textSize = 14f; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(37, 55, 72)); setOnClickListener { action() } }
        parent.addView(b, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 7 })
    }
    private fun label(t: String, s: Float, c: Int, bold: Boolean = false) = TextView(this).apply { text=t; textSize=s; setTextColor(c); if(bold) typeface=Typeface.DEFAULT_BOLD; setPadding(3,7,3,7) }
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1,h) }
    private fun show(title: String, msg: String) = AlertDialog.Builder(this).setTitle(title).setMessage(msg).setPositiveButton("OK", null).show()
    override fun onDestroy() { io.shutdown(); super.onDestroy() }
}
